import cv2
def save_image(filenm):
    cam = cv2.VideoCapture(0)
    cv2.namedWindow("Image")

    ret, frame = cam.read()
    if not ret: print("failed to grab frame")

    cv2.imshow("test", frame)
    img_name = "data/" + filenm + ".png"
    cv2.imwrite(img_name, frame)

    cam.release()
    cv2.destroyAllWindows()
