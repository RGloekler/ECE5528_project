import os, zipfile, time, threading
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt
import cv2

# font
font = cv2.FONT_HERSHEY_SIMPLEX
org = (50, 50)
fontScale = 1
color = (255, 0, 0)
thickness = 2

img_classes = ['cardboard', 'glass', 'metal', 'paper', 'plastic', 'trash']

# Load the TFLite model and allocate tensors.
interpreter = tf.lite.Interpreter(model_path="model.tflite")
interpreter.allocate_tensors()

# Get input and output tensors.
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

# initialize the camera
cam = cv2.VideoCapture(0)

def infer():
  #threading.Timer(2.0, infer).start()
  if not os.path.exists('data/data.png'):
      return
  # load an image and preprocess/resize it
  test_img = image.load_img('data/data.png', target_size=(256, 256))

  # perform inference on that image, update prediction...
  x = image.img_to_array(test_img)
  x = np.expand_dims(x, axis=0)

  # ran inference
  interpreter.set_tensor(input_details[0]['index'], x)
  interpreter.invoke()
  output_data = interpreter.get_tensor(output_details[0]['index'])
  prediction = np.argmax(output_data[0])
  pred_str = img_classes[prediction]
  print(pred_str)
  return pred_str

frame_counter = 0
val_prediction = 'none'
while True:
  ret_val, img = cam.read()
  # overlay text on the image
  image_text = cv2.putText(img, val_prediction, org, font,
  fontScale, color, thickness, cv2.LINE_AA)

  cv2.imshow('Live Inference', image_text)

  if frame_counter % 30 == 0:
      ret_val, img = cam.read()
      cv2.imwrite('data/data.png', img)
      print("Captured image.")

  if frame_counter % 45 == 0:
      val_prediction = infer()

  if cv2.waitKey(1) == 27:
      break  # esc to quit

  frame_counter += 1
cam.release()
cv2.destroyAllWindows()
