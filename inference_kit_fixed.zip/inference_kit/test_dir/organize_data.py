# program to create validation dataset for model
import os, shutil
from pathlib import Path

BASE_PATH = 'Garbage_classification'
data = '/trash'

# get number of files in directory
num_files = 0
for filename in os.listdir(BASE_PATH + data): num_files += 1

# move 10% of files to the validation directory
val = int(num_files * 0.1)

moved = 0
for filename in os.listdir(BASE_PATH + data):
    if moved < val:
        # move the file
        os.rename(BASE_PATH + data + '/' + filename, BASE_PATH + data + '_val/' + filename)
        moved += 1
    else: break
