import os, zipfile, time
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt
import cv2

import save_pic

img_classes = ['cardboard', 'glass', 'metal', 'paper', 'plastic', 'trash']

# Load the TFLite model and allocate tensors.
interpreter = tf.lite.Interpreter(model_path="model.tflite")
interpreter.allocate_tensors()

# Get input and output tensors.
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()

save_pic.save_image('infer_img')

#load an image and preprocess/resize it
img = image.load_img('data/infer_img.png', target_size=(256, 256))


def infer():
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)

    interpreter.set_tensor(input_details[0]['index'], x)
    interpreter.invoke()

    output_data = interpreter.get_tensor(output_details[0]['index'])
    prediction = np.argmax(output_data[0])
    pred_str = img_classes[prediction]
    print(pred_str)
    return pred_str

pred_str = infer() # perform initial inference

while True:
    save_pic.save_image('infer_img')
    img = image.load_img('data/infer_img.png', target_size=(256, 256))
    pred_str = infer()

    img = cv2.imread('data/infer_img.png')
    # The function cv2.imshow() is used to display an image in a window
    cv2.imshow(pred_str, img)
    # waitKey() waits for a key press to close the window and 0 specifies indefinite loop
    cv2.waitKey(0)

    time.sleep(0.1)
    cv2.destroyAllWindows()
